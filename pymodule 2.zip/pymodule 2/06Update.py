from pymongo import MongoClient

try:
    client=MongoClient("mongodb://localhost:27017")
    db=client["office"]
    coll=db["workers"]

    qr={}
    empid=input('Enter empId : ')
    ct=input('Enter city: ')
    dept=input('Enter department: ')
    
    qr["_id"]=empid
    qr["city"]=ct
    qr["department"]=dept


    chval={}
    ct=input('Enter new city: ')
    dept=input('Enter new department: ')
    chval["city"]=ct
    chval["department"]=dept

    upd={"$set":chval}

    coll.update_one(qr,upd)
    print("Employee City and Department data updated Sucessfully...")


except:
    print("Error")