from pymongo import MongoClient

try:
    client=MongoClient("mongodb://localhost:27017")
    db=client["office"]
    coll=db["workers"]

    empid=input('Enter empID: ')
    qr={}
    qr["_id"]=empid

    for doc in coll.find(qr):
        print(doc)
except:
    print("Error")