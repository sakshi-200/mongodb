from pymongo import MongoClient

try:
    client=MongoClient("mongodb://localhost:27017")
    db=client["office"]
    coll=db["workers"]

    dic={}
    empid=input('Enter empID: ')
    empnm=input('Enter empname: ')
    dept=input('Enter department: ')
    pst=input('Enter post: ')
    ct=input('Enter city: ')
    sal=float(input('Enter salary: '))
    mob=int(input('Enter mobile no.:'))
    em=input('Enter email:')

    dic["_id"]=empid
    dic["name"]=empnm
    dic["department"]=dept
    dic["post"]=pst
    dic["city"]=ct
    dic["salary"]=sal
    dic["mobile no."]=mob
    dic["email"]=em

    coll.insert_one(dic)
    print('Employee data added to workers collection sucessfully...')

except:
    print("Error")