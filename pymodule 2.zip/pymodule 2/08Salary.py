from pymongo import MongoClient


try:
        client=MongoClient("mongodb://localhost:27017")
        db=client["office"]
        coll=db["workers"]

        sal=float(input('Enter salary: '))
        qr={}
        
        
        coll.find({"sal":{"$gte":qr}})
        
        
        for doc in coll.find(qr):
         print(doc)


         #result_4 = weekly_demand_collection.find({
   # "checkout_price" : { "$lt" : 200, "$gt" : 100}


except:
    print("Error")
