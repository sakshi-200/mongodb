from pymongo import MongoClient

try:
    client=MongoClient("mongodb://localhost:27017")
    db=client["office"]
    coll1=db["workers"]
    coll2=db["exworkers"]

    empid=input('Enter empID: ')
    qr={}
    qr["_id"]
    
    #coll1.insert_one(coll2)

    coll1.delete_one(qr) 
    print("Emplyoee document deleted sucessfully...")

except:
    print("Error")